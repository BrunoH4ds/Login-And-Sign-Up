from data import user_data

def Login(email, senha):
    email = email.lower()
    senha = senha.lower()

    if (email, senha) in user_data:
        return True, ""
    else:
        return False, "Seu Gmail ou Senha Estao Incorretos"

def Sign_Up(email_cad, senha_cad):
    email_cad = email_cad.lower()
    senha_cad = senha_cad.lower()

    if any(email == email_cad for email, _ in user_data):
        return False, "Este Gmail ja Foi cadastrado"
    else:
        user_data.append((email_cad, senha_cad))
        return True, "Gmail e Senha cadastrados"
