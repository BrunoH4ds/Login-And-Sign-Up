from data import user_data

def Login(email, senha):
    email = email.strip()
    senha = senha.strip()
    if '@' in email:
        Usuario, dominio = email.rsplit('@', 1)
        dominio = dominio.lower()
        email = (f'{Usuario}@{dominio}')
    else:
        return False, "Email inválido. O email deve conter '@'."

    if (email, senha) in user_data:
        return True, "" 
    else:
        return False, "Seu Gmail ou senha estão incorretos."

def Sign_Up(email_cad, senha_cad):
    email_cad = email_cad.strip()
    senha_cad = senha_cad.strip()
    
    if email_cad == '':
        return False, "O campo Gmail Nao pode estar vazio"
    
    if '@' in email_cad:
        Usuario, dominio = email_cad.rsplit('@', 1)
        dominio = dominio.lower()
        if dominio not in {'gmail.com', 'hotmail.com', 'outlook.com'}:
             return False, "Email inválido. Por favor, insira um email válido com @gmail.com, @hotmail.com ou @outlook.com."
    else:
        return False, "Email inválido. O email deve conter '@'."
    
    email_cad = f"{Usuario}@{dominio}"
    
    if any(email == email_cad for email, _ in user_data):
        return False, "Este Gmail já foi cadastrado."

    if len(senha_cad) < 8:
        return False, "Sua senha deve ter pelo menos 8 caracteres. Tente novamente."

    tem_letra = any(c.isalpha() for c in senha_cad)
    tem_numero = any(c.isdigit() for c in senha_cad)
    tem_maiuscula = any(c.isupper() for c in senha_cad)

    if not tem_letra:
        return False, "Sua senha deve conter pelo menos uma letra. Tente novamente."
    if not tem_numero:
        return False, "Sua senha deve conter pelo menos um número. Tente novamente."
    if not tem_maiuscula:
        return False, "Sua senha deve conter pelo menos uma letra maiúscula. Tente novamente."
    
    user_data.append((f"{Usuario}@{dominio}", senha_cad))
    return True, "Gmail e senha cadastrados com sucesso."
